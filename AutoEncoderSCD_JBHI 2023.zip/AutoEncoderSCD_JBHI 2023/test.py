import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
import torch.utils.data as Data
import scipy.io as sio
import os
import numpy as np
from model import model
from tqdm import tqdm
#################################################################
Tar = sio.loadmat('./data/target')  #target data path
test_x = Tar['X']
test_y = Tar['Y']
test_y = test_y.squeeze()

test_x = torch.from_numpy(test_x.astype(np.float32))
test_y = torch.from_numpy(test_y.astype(np.int64))

test_data = Data.TensorDataset(test_x, test_y)
test_data_loader = Data.DataLoader(
        dataset = test_data,
        batch_size = 1,
        shuffle = True,
        drop_last = False
        )

net = model()
print(net)

MODEL_FILE = './trained_models/source.pt'

net.load_state_dict(torch.load(MODEL_FILE))
net.eval()
print('Test a model on the target domain...')

correct = 0
total = 0
i = 0

attention = np.ones((1000,90))

with torch.no_grad():  
    for images, labels in tqdm(test_data_loader):
        
        outputs, _, _, _, _ = net(images,images)
        _, predicted = torch.max(outputs.data, 1)
                        
        prob = F.softmax(outputs, dim=1)
        prob,_  = torch.max(prob.data,1)
        
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
        
                        
print('Accuracy on the target domain: %.4f %%' %(100 * correct / total))