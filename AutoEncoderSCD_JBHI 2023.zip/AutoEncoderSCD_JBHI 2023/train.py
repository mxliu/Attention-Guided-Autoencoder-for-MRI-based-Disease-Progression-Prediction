import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
import torch.utils.data as Data
import torchvision
import numpy as np
import scipy.io as sio
from PIL import Image
from torch.utils.data import Dataset, DataLoader
#matplotlib inline
from model import model
from coral_pytorch import CORAL_loss
from mmd_pytorch import MMD_loss
from tqdm import tqdm

torch.manual_seed(1)

S1 = sio.loadmat('./data/source1') #source data 1 path
train_x = S1['X']
train_y = S1['Y']
train_y = train_y.squeeze()

train_x = torch.from_numpy(train_x.astype(np.float32))
train_y = torch.from_numpy(train_y.astype(np.int64))

train_data = Data.TensorDataset(train_x, train_y)
source_loader = Data.DataLoader(
        dataset = train_data,
        batch_size = 128,
        shuffle = True,
        drop_last = False
        )

S2 = sio.loadmat('./data/source2') #source data 2 path
train_x2 = S2['X']
train_y2 = S2['Y']
train_y2 = train_y2.squeeze()

train_x2 = torch.from_numpy(train_x2.astype(np.float32))
train_y2 = torch.from_numpy(train_y2.astype(np.int64))

train_data2 = Data.TensorDataset(train_x2, train_y2)
target_loader = Data.DataLoader(
        dataset = train_data2,
        batch_size = 128,
        shuffle = True,
        drop_last = False
        )


net = model()
print(model)

optimizer = torch.optim.Adam(net.parameters(), lr=0.001) 
classificationLoss = torch.nn.CrossEntropyLoss()  
reconstructionLoss = torch.nn.L1Loss()
mmdLoss = MMD_loss(kernel_type = 'linear')

max_epoch = 60

wp = 1
wr = 1
wd = 1

i = 0

for epoch in range(max_epoch):
    
    batches = zip(source_loader, target_loader)
    n_batches = min(len(source_loader), len(target_loader))
        
    total_loss = 0
    total_accuracy = 0
    
    for (source_x, y_true), (target_x, _) in tqdm(batches, leave=False, total=n_batches):
  
        y_true = y_true.squeeze()  
                        
        y_hat, x_hat, en1, en2, _ = net(source_x, target_x)
        loss = wp*classificationLoss(y_hat, y_true)+wr*reconstructionLoss(x_hat, target_x)+ wd*mmdLoss(en1, en2)
         
        total_loss += loss.item()
                
        total_accuracy += (y_hat.max(1)[1] == y_true).float().mean().item()

        optimizer.zero_grad()               
        loss.backward()                     
        optimizer.step()                    

    mean_loss = total_loss / n_batches        
    mean_accuracy = total_accuracy / n_batches
    
    tqdm.write(f'EPOCH {epoch:03d}: train_loss={mean_loss:.4f}, train_accuracy={mean_accuracy:.4f} ')    	   
    	
torch.save(net.state_dict(), 'trained_models/source.pt')  
