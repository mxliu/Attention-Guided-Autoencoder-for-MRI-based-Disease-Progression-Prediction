import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
import torch.utils.data as Data
import torchvision
import numpy as np


class model(nn.Module):
    def __init__(self):
        super(model, self).__init__()
        
        self.attention = nn.Sequential(
            nn.Linear(90,90),
            nn.BatchNorm1d(90),
            nn.Softmax()
        ) 
          
        #=========== encoder ================       
        self.encoder = nn.Sequential(
            nn.Linear(90, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            
            nn.Linear(64, 32),
        )
        #=========== decoder ================
        
        self.decoder = nn.Sequential(
            nn.Linear(32, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            
            nn.Linear(64, 90),
            nn.Tanh()
        )
                    
        #=========== classifier ================
        self.cls = nn.Sequential(
            nn.Linear(32, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Linear(64, 2),
        )
    def forward(self, x1, x2):
         prob1 = self.attention(x1)
         prob2 = self.attention(x2)
         x1 = x1.mul(prob1)
         x2 = x2.mul(prob2)
        
         en1 = self.encoder(x1)
         y_hat = self.cls(en1)
         
         en2 = self.encoder(x2)
         x_hat = self.decoder(en2)
                                           
         return y_hat, x_hat, en1, en2, prob1